sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	'sap/m/Dialog',
	'sap/m/Button',
	"chatbot/model/formatter"
], function(Controller, JSONModel, Dialog, Button, formatter) {
	"use strict";

	var geocoder;

	return Controller.extend("chatbot.controller.Main", {

		formatter: formatter,
		/* =========================================================== */
		/* lifecycle methods                                           */
		/* =========================================================== */

		/**
		 * Called when the main controller is instantiated. 
		 * @public
		 */
		onInit: function() {
			this.oModel = new JSONModel({
				chat: []
			});
			this.getView().setModel(this.oModel, "chatmodel");
			//helper model
			this.oViewModel = new JSONModel({
				root: jQuery.sap.getModulePath("chatbot")
			});
			//set model of view
			this.getView().setModel(this.oViewModel, "mainView");
			//generate unique conversationid
			function guid() {
				function s4() {
					return Math.floor((1 + Math.random()) * 0x10000)
						.toString(16)
						.substring(1);
				}
				return s4() + s4() + s4() + s4() + s4() + s4() + s4() + s4();
			}
			this.conversation_id = guid();

		},

		/**
		 * Called when view is rendered. Sends a default message that is not added to chat history
		 * Enable sending question when return button is pressed 
		 * @public
		 */
		onAfterRendering: function() {
			this._sendChat("help", false, false);
			this._initializeEnter(true);
		},

		/* =========================================================== */
		/* event handlers                                              */
		/* =========================================================== */

		/**
		 * Event that is triggered when a emoji is pressed
		 * Referenced in EmojiPopover.fragment.xml
		 * @param {sap.ui.base.Event} oEvent on press event
		 * @public
		 */
		onEmojiPressed: function(oEvent) {
			var emoji = oEvent.getSource().getProperty("text");
			var value = this.byId("MessageInput").getValue();
			this.byId("MessageInput").setValue(value + emoji);
		},

		/**
		 * Opens a popover with emojis when button in footer is pressed
		 * @param {sap.ui.base.Event} oEvent on press event
		 * @public
		 */
		onHandelEmojiPopover: function(oEvent) {
			// create popover
			if (!this._oPopover) {
				this._oPopover = sap.ui.xmlfragment("chatbot.view.EmojiPopover", this);
				this.getView().addDependent(this._oPopover);
			}
			// delay because addDependent will do a async rerendering and the actionSheet will immediately close without it.
			var oButton = oEvent.getSource();
			jQuery.sap.delayedCall(0, this, function() {
				this._oPopover.openBy(oButton);
			});
		},

		onInputVal: function(oEvent) {
			if (oEvent.getParameters("newValue") === "") {
				this.byId("btnSend").setEnabled(false);
			} else {
				this.byId("btnSend").setEnabled(true);
			}
		},

		/**
		 * Sends message in chat box to backend when send button in footer is pressed 
		 * @param {sap.ui.base.Event} oEvent on press event
		 * @public
		 */
		onSendChat: function() {
			var sQuestion = this.byId("MessageInput").getValue();
			this._sendChat(sQuestion, true, true);
		},

		/**
		 * Sends title of button to backend because further information is needed 
		 * @param {sap.ui.base.Event} oEvent on press event
		 * @public
		 */
		onSendBackButton: function(oEvent) {
			this._sendChat(oEvent.getSource().getBindingContext("chatmodel").getProperty("value"), false, true);
		},

		/**
		 * Scrolls to the end of the chat history when new message is added 
		 * This is triggered when list is updated
		 * css classes are manually added/removed depending who added the message
		 * we have to check at least the last 2 items because the busy bubble is added
		 * right after adding the question
		 * @param {sap.ui.base.Event} oEvent on update list event
		 * @public
		 */
		scrollToLastMessage: function(oEvent) {
			//check length of items
			if (oEvent.getParameter("actual") === 0) {
				return;
			}
			if (oEvent.getSource().getAggregation("items")) {
				//change css class
				var aItems = oEvent.getSource().getAggregation("items");
				var oItem = aItems[aItems.length !== 0 ? aItems.length - 1 : 0];
				var oPrevious = aItems[aItems.length > 2 ? aItems.length - 2 : 0];
				var sAuthor = oItem.getBindingContext("chatmodel").getProperty("author");
				if (oPrevious.getBindingContext("chatmodel").getProperty("author") === "User") {
					oPrevious.getAggregation("content")[0].getAggregation("items")[1].removeStyleClass("botreply");
					oPrevious.getAggregation("content")[0].getAggregation("items")[1].addStyleClass("botquestion");
				}
				if (sAuthor === "User") {
					oItem.getAggregation("content")[0].getAggregation("items")[1].removeStyleClass("botreply");
					oItem.getAggregation("content")[0].getAggregation("items")[1].addStyleClass("botquestion");
				}
				oEvent.getSource().getAggregation("items")[0].getAggregation("content")[0].getAggregation("items")[1].addStyleClass("botquestion");
				/*window.setTimeout(function() {*/
					oItem.getDomRef().scrollIntoView({
						behavior: "auto"
					});
			/*	}, 50);*/
			}
		},

		/** 
		 * Event when list is pressed 
		 * Recast.ai rich message type list
		 */
		onHandlePressList: function(oEvent) {

			var sHTML = oEvent.getSource().oPropagatedProperties.oBindingContexts.chatmodel.getProperty("subtitle");
			var oBtn = oEvent.getSource().oPropagatedProperties.oBindingContexts.chatmodel.getProperty("buttons/0");
			var sTitle = oEvent.getSource().getProperty("text");
			var that = this;

			if (!this.dialogApp) {
				this.dialogApp = new Dialog({
					title: sTitle,
					type: 'Message',
					beginButton: new Button({
						text: 'Close',
						press: function() {
							that.dialogApp.close();
						}
					}),
					afterClose: function() {
						that.dialogApp.close();
					}
				});

				var box = new sap.m.VBox({
					width: "100%",
					items: [
						new sap.m.Text({
							text: sHTML
						}),
						new sap.m.Link({
							text: oBtn.title,
							target: "_blank",
							href: oBtn.value
						})
					]
				});

				this.dialogApp.addContent(box);
			} else {
				this.dialogApp.setTitle(sTitle);
				this.dialogApp.getContent()[0].getItems()[0].setText(sHTML);
				this.dialogApp.getContent()[0].getItems()[1].setText(oBtn.title);
				this.dialogApp.getContent()[0].getItems()[1].setHref(oBtn.value);
			}

			this.dialogApp.open();

		},
		
		/** 
		 * Event when list is pressed 
		 * Recast.ai rich message type carouseladapted
		 */
		onHandlePressListCarousel : function(oEvent){
			var oChatModel = oEvent.getSource().oPropagatedProperties.oBindingContexts.chatmodel;
			var that = this;
			if (!this._carouselDialog) {
				this._carouselDialog = sap.ui.xmlfragment(this.getView().getId(), "chatbot.view.CarouselAdapted", this);
				this.getView().addDependent(this._carouselDialog);
			} 
			this._carouselDialog.setModel(new JSONModel({
				buttons: oChatModel.getProperty("buttons")
			}));
			this._carouselDialog.open();
		},
		
		/**
		 * Post question from help menu
		 * Add question to message history
		 */
		onPressHelpLink : function(oEvent){
			this._carouselDialog.close();
			this.aData = this.getView().getModel("chatmodel").getProperty("/chat");

			var userInput = {
				content: oEvent.getSource().getProperty("text"),
				author: "User",
				type: "text"
			};
			this.aData.push(userInput);
			this._sendChat(oEvent.getSource().oPropagatedProperties.oBindingContexts.undefined.getProperty("value"), false, true);
		},
		
		/**
		 * Close attachment dialog that opens on desktop devices to upload images for Schadensmeldungen
		 */
		onPressCancelDialog: function(oEvent) {
			this._carouselDialog.close();
		},

		/* =========================================================== */
		/* begin: internal methods                                     */
		/* =========================================================== */

		/**
		 * Enables sending message when return button is clicked
		 * @param {boolean} bEnable shows if returning question with enter should be enabled
		 */
		_initializeEnter: function(bEnable) {
			if (!bEnable) {
				return;
			}
			this.byId("MessageInput").onsapenter = function(e) {
				if (sap.m.InputBase.prototype.onsapenter) {
					sap.m.InputBase.prototype.onsapenter.apply(this, arguments);
				}
				this.getParent().getAggregation("items")[2].firePress({
					source: this.getParent().getAggregation("items")[2]
				});
				//prevent that new line is added
				return;
			};
		},

		/**
		 * Triggers ajax call to backend with question 
		 * Receives answer and shows it in the history
		 * @param {String} sQuestion text in chatbox
		 * @param {boolean} bAdd signals if question should be added to history
		 * @private
		 */
		_sendChat: function(sQuestion, bAdd, bBusy) {
			var that = this;
			this.oModel = this.getView().getModel("chatmodel");
			this.aData = this.oModel.getProperty("/chat");

			//generate request payload
			this.enteredData = {};
			this.enteredData.authtoken = "4PZPPUDUGFZROIP6LOUUI4TX5CAV7FTZ";
			this.enteredData.question = sQuestion;
			this.enteredData.conversation_id = this.conversation_id;
			
			var userInput = {
				content: this.enteredData.question,
				author: "User",
				type: "text"
			};
			
			this.byId("MessageInput").setValue("");
			
			if (bAdd) {
				that.aData.push(userInput);
			}
			
			//set dummy item for signaling that bot is writing
			//timeout is needed so that update event of list is called properly
			if (bBusy){
				/*window.setTimeout(function() {*/
					that.aData.push({
						author : "bot",
						type : "waiting"
					});
			/*	}, 0);*/
			}
			

			this.oModel.setProperty("/chat", this.aData);

			this.byId("MessageInput").setEnabled(false);
			$.ajax({
				type: "POST",
				url: "/api/askQuestion",
				crossDomain: true,
				datatype: 'json',
				context: this,
				contentType: "application/json",
				data: JSON.stringify(this.enteredData),
				success: function(data) {
					//enable inputfield
					that.byId("MessageInput").setEnabled(true);
					that.byId("MessageInput").setValue("");
					//remove busy indicator
					if (that.aData.length > 0 && that.aData[that.aData.length -1].type === "waiting"){
						that.aData.splice(-1,1);
					}
					var oAddMsg = function(oMsg) {
						return new Promise(function(fnResolve, fnReject) {
							that.aData.push(oMsg);
							that.oModel.setProperty("/chat", that.aData);
						});
					};
					for (var i = 0; i < data.length; i++) {
						var oMsg = JSON.parse(JSON.stringify(data[i]));
						setTimeout(oAddMsg, i * 1000, JSON.parse(JSON.stringify(oMsg)));
					}
				},
				error: function(err) {
					that.byId("MessageInput").setEnabled(true);
				}
			});
		}
	});
});